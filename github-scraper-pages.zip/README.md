# 크롤링 → HTML → GitHub Pages 자동 배포

특정 사이트를 예약(cron)으로 크롤링해서 `index.html` 을 만들고,
GitHub Pages 공개 페이지에 자동 배포하는 템플릿입니다.

```
cron 예약 → build.py 실행(크롤링) → index.html 생성 → Pages 배포
```

## 📂 파일 구성

```
├─ build.py                          # 크롤링 + HTML 생성 스크립트
├─ requirements.txt                  # 파이썬 의존성 (requests, beautifulsoup4)
├─ index.html                        # 실행 시 자동 생성됨 (커밋 안 해도 됨)
└─ .github/
   └─ workflows/
      └─ scrape-and-deploy.yml       # 예약 실행 + Pages 배포 워크플로
```

---

## 🚀 GitHub에 올리는 절차

### 1) 새 저장소 만들기
- GitHub에서 **New repository** → 이름 지정 → **Public** 선택 → Create.
  (GitHub Free 공개 저장소에서 Pages 무료 사용 가능)

### 2) 파일 업로드
아래 둘 중 편한 방법으로 이 폴더의 파일을 올립니다.

**A. 웹에서 업로드**
- 저장소 → **Add file → Upload files** 로 `build.py`, `requirements.txt` 업로드.
- `.github/workflows/scrape-and-deploy.yml` 은 **Add file → Create new file** 에서
  파일명 칸에 `.github/workflows/scrape-and-deploy.yml` 을 그대로 입력하면
  폴더가 자동 생성됩니다. 내용 붙여넣고 커밋.

**B. 로컬 git 사용**
```bash
git init
git add .
git commit -m "init: scraper + pages"
git branch -M main
git remote add origin https://github.com/<사용자명>/<저장소명>.git
git push -u origin main
```

### 3) Pages 소스를 "GitHub Actions"로 설정 ⭐필수
- 저장소 **Settings → Pages** 이동.
- **Build and deployment → Source** 를 **GitHub Actions** 로 변경.
  (이걸 안 하면 배포 단계에서 실패합니다.)

### 4) 실행
- **Actions 탭 → Scrape and Deploy → Run workflow** 로 즉시 수동 실행.
- 또는 매일 예약 시각(기본 UTC 00:07 = KST 09:07)에 자동 실행됩니다.
- 완료되면 워크플로 로그 맨 아래 **deploy** 단계에 페이지 URL이 표시됩니다.
  주소 형태: `https://<사용자명>.github.io/<저장소명>/`

---

## ✏️ 내 사이트로 바꾸기

`build.py` 상단 **CONFIG** 와 `parse()` 함수만 고치면 됩니다.

```python
TARGET_URL = "https://내가-크롤링할-사이트.com/"
PAGE_TITLE = "원하는 제목"
USER_AGENT = "my-scraper (contact: 내이메일)"
```

`parse()` 안의 CSS 선택자(`div.quote`, `span.text` 등)를
대상 사이트의 실제 HTML 구조에 맞게 수정하세요.
(브라우저 개발자도구 F12 → 원하는 요소 우클릭 → Copy → Copy selector 활용)

### 로컬에서 먼저 테스트
```bash
pip install -r requirements.txt
python build.py          # index.html 생성 확인
```
브라우저로 `index.html` 을 열어 결과를 확인한 뒤 push 하면 됩니다.

---

## ⏰ 실행 주기 바꾸기

`.github/workflows/scrape-and-deploy.yml` 의 cron 값을 수정합니다.
**시간은 항상 UTC 기준** 입니다. (KST = UTC + 9시간)

| 원하는 주기            | cron 값          |
|------------------------|------------------|
| 매일 KST 09:07         | `'7 0 * * *'`    |
| 매시간 정각 근처       | `'5 * * * *'`    |
| 매주 월요일 KST 09:00  | `'0 0 * * 1'`    |
| 6시간마다              | `'0 */6 * * *'`  |

- cron 표현식은 반드시 **작은따옴표**로 감쌉니다.
- 최소 간격은 **5분**입니다.
- [crontab.guru](https://crontab.guru) 에서 표현식을 미리 검증하세요.

---

## ⚠️ 주의사항

**GitHub Actions 제약**
- 공개 저장소의 예약 워크플로는 **60일간 저장소 활동이 없으면 자동 비활성화**됩니다.
- 스케줄은 부하가 높은 정각 시간대에 지연될 수 있어, 정각을 살짝 피한 시각을 권장합니다.
- 예약 워크플로는 **기본 브랜치(main)** 에서만 동작합니다.

**크롤링 관련 (법적·윤리적으로 중요)**
- 대상 사이트의 **robots.txt** 와 **이용약관(ToS)** 을 반드시 확인하세요.
  (크롤링·재게시를 금지하는 사이트가 많습니다.)
- 남의 사이트 본문을 그대로 긁어 공개 페이지에 **재게시하면 저작권 침해**가 될 수 있습니다.
  원문 전재 대신 **링크·요약·본인 가공 데이터** 형태를 권장합니다.
- 공개 **API가 있으면 크롤링보다 API 사용**이 훨씬 안정적이고 안전합니다.
- 과도한 요청으로 대상 서버에 부담을 주지 마세요.

---

## 참고 출처
- GitHub Docs — Events that trigger workflows
  https://docs.github.com/actions/using-workflows/events-that-trigger-workflows
- GitHub Docs — Using custom workflows with GitHub Pages
  https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- GitHub Docs — Building and testing Python
  https://docs.github.com/en/actions/language-and-framework-guides/using-python-with-github-actions
