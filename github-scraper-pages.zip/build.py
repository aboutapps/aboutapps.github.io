"""
사이트를 크롤링해서 index.html 을 생성하는 스크립트.

기본값은 스크래핑 연습용으로 공개된 사이트(quotes.toscrape.com)라
클론 후 바로 실행/배포하며 동작을 확인할 수 있습니다.
실제 사이트로 바꿀 때는 아래 CONFIG 와 parse() 함수만 수정하세요.
반드시 대상 사이트의 robots.txt 와 이용약관을 먼저 확인하세요.
"""

import html
from datetime import datetime, timezone

import requests
from bs4 import BeautifulSoup

# ── 설정 ─────────────────────────────────────────────
TARGET_URL = "https://quotes.toscrape.com/"     # ← 크롤링할 사이트로 변경
PAGE_TITLE = "수집 결과"                          # ← 페이지 제목
USER_AGENT = "my-scraper (contact: you@example.com)"  # ← 연락처 넣기(관행)
# ─────────────────────────────────────────────────────


def fetch(url: str) -> str:
    """대상 페이지 HTML 을 가져온다."""
    res = requests.get(url, timeout=20, headers={"User-Agent": USER_AGENT})
    res.raise_for_status()
    return res.text


def parse(page_html: str) -> list[dict]:
    """
    원하는 데이터를 추출한다.
    ↓↓↓ 이 부분을 대상 사이트 구조에 맞게 수정하세요 ↓↓↓
    """
    soup = BeautifulSoup(page_html, "html.parser")
    items = []
    for q in soup.select("div.quote"):
        text = q.select_one("span.text")
        author = q.select_one("small.author")
        items.append(
            {
                "title": text.get_text(strip=True) if text else "",
                "meta": author.get_text(strip=True) if author else "",
            }
        )
    return items
    # ↑↑↑ 여기까지 ↑↑↑


def render(items: list[dict]) -> str:
    """추출한 데이터를 HTML 문자열로 만든다."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    rows = "\n".join(
        f"""      <li>
        <div class="t">{html.escape(it['title'])}</div>
        <div class="m">{html.escape(it['meta'])}</div>
      </li>"""
        for it in items
    )

    return f"""<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(PAGE_TITLE)}</title>
  <style>
    :root {{ color-scheme: light dark; }}
    body {{ font-family: system-ui, sans-serif; max-width: 760px;
            margin: 40px auto; padding: 0 16px; line-height: 1.6; }}
    h1 {{ margin-bottom: 4px; }}
    .updated {{ color: #888; font-size: 14px; margin-bottom: 24px; }}
    ul {{ list-style: none; padding: 0; }}
    li {{ border: 1px solid #8883; border-radius: 10px;
          padding: 14px 16px; margin-bottom: 12px; }}
    .t {{ font-size: 16px; }}
    .m {{ color: #888; font-size: 13px; margin-top: 6px; }}
  </style>
</head>
<body>
  <h1>{html.escape(PAGE_TITLE)}</h1>
  <p class="updated">업데이트: {now} · 총 {len(items)}건</p>
  <ul>
{rows}
  </ul>
</body>
</html>
"""


def main() -> None:
    page_html = fetch(TARGET_URL)
    items = parse(page_html)
    output = render(items)
    with open("index.html", "w", encoding="utf-8") as f:
        f.write(output)
    print(f"index.html 생성 완료 · {len(items)}건")


if __name__ == "__main__":
    main()
